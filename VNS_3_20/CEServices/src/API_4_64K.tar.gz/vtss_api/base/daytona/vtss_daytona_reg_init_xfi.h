/*

 Vitesse Switch Software.

 Copyright (c) 2002-2012 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.

 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.

 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.

 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.

*/
#ifndef _VTSS_DAYTONA_REG_INIT_XFI_H
#define _VTSS_DAYTONA_REG_INIT_XFI_H

// Settings for mode WORK

#define  VTSS_XFI_XFI_CONTROL_XFI_MODE_TX_AUTORESYNC_WORK                                           VTSS_F_XFI_XFI_CONTROL_XFI_MODE_TX_AUTORESYNC(0x0)


// Settings for mode PROT

#define  VTSS_XFI_XFI_CONTROL_XFI_MODE_TX_AUTORESYNC_PROT                                           VTSS_F_XFI_XFI_CONTROL_XFI_MODE_TX_AUTORESYNC(0x0)


// Settings for mode W_P

#define  VTSS_XFI_XFI_CONTROL_XFI_MODE_TX_AUTORESYNC_W_P                                            VTSS_F_XFI_XFI_CONTROL_XFI_MODE_TX_AUTORESYNC(0x0)


// Settings for mode UNUSED

#define  VTSS_XFI_XFI_CONTROL_XFI_MODE_TX_AUTORESYNC_UNUSED                                         VTSS_F_XFI_XFI_CONTROL_XFI_MODE_TX_AUTORESYNC(0x0)




typedef enum {
    BM_XFI_WORK,
    BM_XFI_PROT,
    BM_XFI_W_P,
    BM_XFI_UNUSED,
    BM_XFI_LAST
} block_xfi_mode_t;

#endif /* _VTSS_DAYTONA_REG_INIT_XFI_H */
