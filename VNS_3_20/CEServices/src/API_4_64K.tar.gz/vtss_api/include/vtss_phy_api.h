/*

 Vitesse API software.

 Copyright (c) 2002-2012 Vitesse Semiconductor Corporation "Vitesse". All
 Rights Reserved.

 Unpublished rights reserved under the copyright laws of the United States of
 America, other countries and international treaties. Permission to use, copy,
 store and modify, the software and its source code is granted. Permission to
 integrate into other products, disclose, transmit and distribute the software
 in an absolute machine readable format (e.g. HEX file) is also granted.  The
 source code of the software may not be disclosed, transmitted or distributed
 without the written permission of Vitesse. The software and its source code
 may only be used in products utilizing the Vitesse switch products.

 This copyright notice must appear in any copy, modification, disclosure,
 transmission or distribution of the software. Vitesse retains all ownership,
 copyright, trade secret and proprietary rights in the software.

 THIS SOFTWARE HAS BEEN PROVIDED "AS IS," WITHOUT EXPRESS OR IMPLIED WARRANTY
 INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR USE AND NON-INFRINGEMENT.

 $Id$
 $Revision$

*/

/**
 * \file
 * \brief PHY API
 * \details This header file describes PHY control functions
 */

#ifndef _VTSS_PHY_API_H_
#define _VTSS_PHY_API_H_

#include <vtss_options.h>
#include <vtss_types.h>
#ifdef VTSS_CHIP_CU_PHY

/** \brief PHY part ids supported */
typedef enum {
    VTSS_PHY_TYPE_NONE = 0,    /* Unknown */
    VTSS_PHY_TYPE_8201 = 8201, /* VSC8201 (Mustang) */
    VTSS_PHY_TYPE_8204 = 8204, /* VSC8204 (Blazer) */
    VTSS_PHY_TYPE_8211 = 8211, /* VSC8211 (Cobra) */
    VTSS_PHY_TYPE_8221 = 8221, /* VSC8221 (Cobra) */
    VTSS_PHY_TYPE_8224 = 8224, /* VSC8224 (Quattro) */
    VTSS_PHY_TYPE_8234 = 8234, /* VSC8234 (Quattro) */
    VTSS_PHY_TYPE_8244 = 8244, /* VSC8244 (Quattro) */
    VTSS_PHY_TYPE_8538 = 8538, /* VSC8538 (Spyder) */
    VTSS_PHY_TYPE_8558 = 8558, /* VSC8558 (Spyder) */
    VTSS_PHY_TYPE_8574 = 8574, /* VSC8574 (Tesla) */
    VTSS_PHY_TYPE_8504 = 8504, /* VSC8504 (Tesla) */
    VTSS_PHY_TYPE_8572 = 8572, /* VSC8572 (Tesla) */
    VTSS_PHY_TYPE_8552 = 8552, /* VSC8552 (Tesla) */
    VTSS_PHY_TYPE_8502 = 8502, /* VSC8502 (Tesla) */
    VTSS_PHY_TYPE_8658 = 8658, /* VSC8658 (GTO) */
    VTSS_PHY_TYPE_8601 = 8601, /* VSC8601 (Cooper) */
    VTSS_PHY_TYPE_8641 = 8641, /* VSC8641 (Cooper) */
    VTSS_PHY_TYPE_7385 = 7385, /* VSC7385 (Northolt) */
    VTSS_PHY_TYPE_7388 = 7388, /* VSC7388 (Luton) */
    VTSS_PHY_TYPE_7389 = 7389, /* VSC7389, VSC7391 (Luton16/16r) */
    VTSS_PHY_TYPE_7390 = 7390, /* VSC7390 (Luton24) */
    VTSS_PHY_TYPE_7395 = 7395, /* VSC7395, VSC7396 (Luton5e/5m) */
    VTSS_PHY_TYPE_7398 = 7398,  /* VSC7398, (Luton8) */
    VTSS_PHY_TYPE_7500 = 7500,  /* VSC7500 (Intrigue) */
    VTSS_PHY_TYPE_7501 = 7501,  /* VSC7501 (Intrigue) */
    VTSS_PHY_TYPE_7502 = 7502,  /* VSC7502 (Intrigue) */
    VTSS_PHY_TYPE_7503 = 7503,  /* VSC7503 (Intrigue) */
    VTSS_PHY_TYPE_7504 = 7504,  /* VSC7504 (Intrigue) */
    VTSS_PHY_TYPE_7505 = 7505,  /* VSC7505 (Intrigue) */
    VTSS_PHY_TYPE_7506 = 7506,  /* VSC7506 (Intrigue) */
    VTSS_PHY_TYPE_7507 = 7507,  /* VSC7507 (Intrigue) */
    VTSS_PHY_TYPE_8634 = 8634,  /* VSC8634 (Enzo) */
    VTSS_PHY_TYPE_8664 = 8664,  /* VSC8664 (Enzo) */  
    VTSS_PHY_TYPE_8512 = 8512,  /* VSC8512 (Atom12) */
    VTSS_PHY_TYPE_8522 = 8522,  /* VSC8522 (Atom12) */
    VTSS_PHY_TYPE_7420 = 7420   /* VSC7420 (Luton26) */  
} vtss_phy_part_number_t; 

/** \brief PHY LED modes */
typedef enum {
  LINK_ACTIVITY, /** No link in any speed on any media interface./Valid link at any speed on any media interface. Blink or pulse-stretch = Valid link at any speed on any media interface with activity present.*/
  LINK1000_ACTIVITY, /** No link in 1000BASE-T/Valid 1000BASE-T link. Blink or pulse-stretch = Valid 1000BASE-T link with activity present*/
  LINK100_ACTIVITY, /** No link in 100BASE-T/Valid 100BASE-T link. Blink or pulse-stretch = Valid 100BASE-T link with activity present*/
  LINK10_ACTIVITY, /** No link in 10BASE-T/Valid 10BASE-T link. Blink or pulse-stretch = Valid 10BASE-T link with activity present*/
  LINK100_1000_ACTIVITY, /** No link in 100BASE-T, 1000BASE-FX, or 1000BASE-TX/Valid 100BASE-T, 1000BASE-FX, or 1000BASE-TX link.Blink or pulse-stretch = Valid 100BASE-T, 1000BASE-FX, or 1000BASE-TX link with activity present.*/
  LINK10_1000_ACTIVITY, /** No link in 10BASE-T, 1000BASE-FX, or 1000BASE-TX/Valid 10BASE-T, 1000BASE-FX, or 1000BASE-TX link.Blink or pulse-stretch = Valid 10BASE-T, 1000BASE-FX, or 1000BASE-TX link with activity present.*/
  LINK10_100_ACTIVITY, /** No link in 10BASE-T, 100BASE-FX, or 100BASE-TX/Valid 10BASE-T, 100BASE-FX, or 100BASE-TX link.Blink or pulse-stretch = Valid 10BASE-T, 100BASE-FX, or 100BASE-TX link with activity present.*/
  LINK100BASE_FX_1000BASE_X_ACTIVITY, /** No link in 100BASE-FX or 1000BASE-X/ Valid 100BASE-FX or 1000BASE-X link. Blink or pulse-stretch = Valid 100BASE-FX or 1000BASE-X link with activity present.*/
  DUPLEX_COLLISION, /** Link established in half-duplex mode, or no link established. Link established in full-duplex mode.Blink or pulse-stretch = Link established in half-duplex mode but collisions are present*/
  COLLISION, /**No collision detected.Blink or pulse-stretch = Collision detected.*/
  ACTIVITY,  /** No activity present.Blink or pulse-stretch = Activity present*/
  BASE100_FX_1000BASE_X_FIBER_ACTIVITY, /**No 100BASE-FX or 1000BASE-X activity present. Blink or pulse-stretch = 100BASE-FX or 1000BASE-X activity present */
  AUTONEGOTIATION_FAULT,  /**No autonegotiation fault present., Autonegotiation fault occurred.*/
  LINK1000BASE_X_ACTIVITY, /**No link in 1000BASE-X. Valid 1000BASE-X link.*/
  LINK100BASE_FX_ACTIVITY, /**No link in 100BASE-FX.*/
  BASE1000_ACTIVITY,   /**No 1000BASE-X activity present.Blink or pulse-stretch = 1000BASE-X activity present.*/
  BASE100_FX_ACTIVITY, /**No 100BASE-FX activity present, Blink or pulse-stretch = 100BASE-FX activity present.*/
  FORCE_LED_OFF,  /** De-asserts the LED*/
  FORCE_LED_ON,   /** Asserts the LED*/
  FAST_LINK_FAIL, /** Enable fast link fail on the LED*/
} vtss_phy_led_mode_t; 


/** \brief List of LED pins per port */
typedef enum {
  LED0,
  LED1,
  LED2,
  LED3  
} vtss_phy_led_number_t;


/** \brief LED model selection */
typedef struct
{
  vtss_phy_led_mode_t mode; /**< LED blink mode*/
  vtss_phy_led_number_t number; /**< Which LED to configure with the above mode*/
} vtss_phy_led_mode_select_t;

/** \brief Phy type information */
typedef struct
{
    u16             part_number;    /**< Part number */
    u16             revision;       /**< Chip revision */
    u8              port_cnt;       /**< The number of PHY ports in the chip */
    u16             channel_id;     /**< Channel id */
    u16             base_port_no;   /**< The port number for the first PHY port within the chip.   */
    vtss_port_no_t  phy_api_base_no;/**< First API no within this phy (in' case of multiple channels) */
} vtss_phy_type_t;


// Defines for micro patch configuration settings 
#define MAX_CFG_BUF_SIZE 36 /**< Defines the number bytes in the PHY patch settings array */
#define MAX_STAT_BUF_SIZE 8 /**< Defines the number bytes in the PHY patch status array */



/* - Reset --------------------------------------------------------- */

/** \brief PHY media interface type */
typedef enum {
    VTSS_PHY_MEDIA_IF_CU,                      /**< Copper Interface */
    VTSS_PHY_MEDIA_IF_SFP_PASSTHRU,            /**< Fiber/Cu SFP Pass-thru */
    VTSS_PHY_MEDIA_IF_FI_1000BX,               /**< 1000Base-X */
    VTSS_PHY_MEDIA_IF_FI_100FX,                /**< 100Base-FX */
    VTSS_PHY_MEDIA_IF_AMS_CU_PASSTHRU,         /**< AMS - Cat5/SerDes/CuSFP passthru */
    VTSS_PHY_MEDIA_IF_AMS_FI_PASSTHRU,
    VTSS_PHY_MEDIA_IF_AMS_CU_1000BX,	       /**< AMS - Cat5/1000BX/CuSFP */
    VTSS_PHY_MEDIA_IF_AMS_FI_1000BX,
    VTSS_PHY_MEDIA_IF_AMS_CU_100FX	,          /**< AMS - Cat5/100FX/CuSFP */
    VTSS_PHY_MEDIA_IF_AMS_FI_100FX
} vtss_phy_media_interface_t;

/** \brief PHY media interface type */
typedef enum {
    VTSS_PHY_MDIX_AUTO,                /**< Copper media MDI auto detected */
    VTSS_PHY_MDI,                      /**< Copper media forced to MDI */
    VTSS_PHY_MDIX,                     /**< Copper media forced to MDI-X (Crossed cable) */
} vtss_phy_mdi_t;


/** \brief PHY RGMII configuration */
typedef struct {
    u16 rx_clk_skew_ps; /**< Rx clock skew in pico seconds */
    u16 tx_clk_skew_ps; /**< Tx clock skew in pico seconds */
} vtss_phy_rgmii_conf_t;

/** \brief PHY TBI configuration */
typedef struct {
    BOOL aneg_enable;  /**< Enable auto negotiation */
} vtss_phy_tbi_conf_t;

/** \brief PHY reset structure */
typedef struct {
    vtss_port_interface_t      mac_if;   /**< MAC interface */
    vtss_phy_media_interface_t media_if; /**< Media interface */
    vtss_phy_rgmii_conf_t      rgmii;    /**< RGMII setup */
    vtss_phy_tbi_conf_t        tbi;      /**< TBI setup */
    BOOL					   i_cpu_en; /**< iCPU Enable */
} vtss_phy_reset_conf_t;


/**
 * \brief Must be call previous to port PHY Reset (vtss_phy_reset).
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number (MUST be the first port for the chip).
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_pre_reset(const vtss_inst_t           inst,
                           const vtss_port_no_t        port_no);


/**
 * \brief Must be call after port PHY Reset (vtss_phy_reset).
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number (Any port with the chip can be used).
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_post_reset(const vtss_inst_t           inst,
                            const vtss_port_no_t        port_no);


/**
 * \brief Must be call before a system reset.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number (Any port with the chip can be used).
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_pre_system_reset(const vtss_inst_t           inst,
                                  const vtss_port_no_t        port_no);



/**
 * \brief Reset PHY.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param conf [IN]     Reset configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_reset(const vtss_inst_t           inst,
                       const vtss_port_no_t        port_no,
                       const vtss_phy_reset_conf_t *const conf);

/** 
 * \brief Get reset configuration
 *
 * \param inst [IN]  Target instance reference
 * \param port_no [IN]  Port number (Any port within the chip can be used)
 * \param conf [OUT] Reset configuration
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_reset_get(const vtss_inst_t           inst,
                           const vtss_port_no_t        port_no,
                           vtss_phy_reset_conf_t       *conf);


/* - Main configuration and status --------------------------------- */

/** \brief PHY mode */
typedef enum {
    VTSS_PHY_MODE_ANEG,       /**< Auto negoatiation */
    VTSS_PHY_MODE_FORCED,     /**< Forced mode */
    VTSS_PHY_MODE_POWER_DOWN  /**< Power down (disabled) */
} vtss_phy_mode_t;

/** \brief PHY forced mode configuration */
typedef struct {
    vtss_port_speed_t speed; /**< Speed */
    BOOL              fdx;   /**< Full duplex */
} vtss_phy_forced_t;

/** \brief PHY auto negotiation advertisement */
typedef struct {
    BOOL speed_10m_hdx;    /**< 10Mbps, half duplex */
    BOOL speed_10m_fdx;    /**< 10Mbps, full duplex */
    BOOL speed_100m_hdx;   /**< 100Mbps, half duplex */
    BOOL speed_100m_fdx;   /**< 100Mbps, full duplex */
    BOOL speed_1g_fdx;     /**< 1000Mpbs, full duplex */
    BOOL symmetric_pause;  /**< Symmetric pause */
    BOOL asymmetric_pause; /**< Asymmetric pause */
} vtss_phy_aneg_t;

/** \brief PHY configuration */
typedef struct {
    vtss_phy_mode_t   mode;   /**< PHY mode */
    vtss_phy_forced_t forced; /**< Forced mode configuration */
    vtss_phy_aneg_t   aneg;   /**< Auto-negotiation mode configuration */
    vtss_phy_mdi_t    mdi;    /**< Cu cable MDI (Crossed cable / normal cable) */
} vtss_phy_conf_t;




/** 
 * \brief Get chip temperature
 *
 * \param inst [IN]  Target instance reference
 * \param port_no [IN]  Port number (Any port within the chip can be used).
 * \param temp [OUT] Chip temperature
 *
 * \return Return code.
 **/

vtss_rc vtss_phy_chip_temp_get(const vtss_inst_t inst,
                               const vtss_port_no_t port_no,
                               i16        *const temp);


/** 
 * \brief Init. chip temperature
 *
 * \param inst [IN]       Target instance reference
 * \param port_no [IN]  Port number (Any port within the chip can be used).
 *
 * \return Return code.
 **/

vtss_rc vtss_phy_chip_temp_init(const vtss_inst_t inst,
                                const vtss_port_no_t port_no);


/**
 * \brief Get PHY configuration.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param conf [OUT]    PHY configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_conf_get(const vtss_inst_t    inst,
                          const vtss_port_no_t port_no,
                          vtss_phy_conf_t      *const conf);

/**
 * \brief Set PHY configuration.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param conf [IN]     PHY configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_conf_set(const vtss_inst_t     inst,
                          const vtss_port_no_t  port_no,
                          const vtss_phy_conf_t *const conf);

/**
 * \brief Get PHY status.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param status [OUT]  PHY status.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_status_get(const vtss_inst_t    inst,
                            const vtss_port_no_t port_no,
                            vtss_port_status_t   *const status);

/* - 1G configuration and status ----------------------------------- */

/**
 * \brief Get the PHY type/id.
 * The the Phy ID - can only be used after setting the operating mode 
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param phy_id [OUT]  PHY Type/id.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_id_get(const vtss_inst_t   inst, 
                        const vtss_port_no_t  port_no, 
                        vtss_phy_type_t *phy_id);

/** \brief PHY 1G configuration */
typedef struct {
    struct {
        BOOL cfg;                               /**< Manual Master/Slave Config. 1=enabled */
        BOOL val;                               /**< Master/Slave Config value, 1=Master */
    } master;                             /**< Master/Slave Mode */
} vtss_phy_conf_1g_t;

/**
 * \brief Get PHY 1G configuration.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param conf [OUT]    PHY 1G configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_conf_1g_get(const vtss_inst_t     inst,
                             const vtss_port_no_t  port_no,
                             vtss_phy_conf_1g_t    *const conf);

/**
 * \brief Set PHY 1G configuration.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param conf [IN]     PHY 1G configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_conf_1g_set(const vtss_inst_t         inst,
                             const vtss_port_no_t      port_no,
                             const vtss_phy_conf_1g_t  *const conf);

/** \brief PHY 1G status */
typedef struct {
    BOOL master_cfg_fault;  /**< Master/Slave Configuration fault */
    BOOL master;                   /**< Master = 1, Slave = 0 */
} vtss_phy_status_1g_t;

/**
 * \brief Get PHY 1G status.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param status [OUT]  PHY 1G status.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_status_1g_get(const vtss_inst_t     inst,
                               const vtss_port_no_t  port_no,
                               vtss_phy_status_1g_t  *const status);

/* - Power configuration and status -------------------------------- */


#define VTSS_PHY_POWER_ACTIPHY_BIT 0 /**< Defines the bit used to signaling that ActiPhy is enabled */
#define VTSS_PHY_POWER_DYNAMIC_BIT 1 /**< Defines the bit used to signaling that PerfectReach is enabled */

/** \brief PHY power reduction modes */
typedef enum {
    VTSS_PHY_POWER_NOMINAL = 0, /**< Default power settings */
    VTSS_PHY_POWER_ACTIPHY = 1 << VTSS_PHY_POWER_ACTIPHY_BIT, /**< ActiPHY - Link down power savings enabled (Bit 0) */
    VTSS_PHY_POWER_DYNAMIC = 1 << VTSS_PHY_POWER_DYNAMIC_BIT, /**< PerfectReach - Link up power savings enabled (Bit 1) */
    VTSS_PHY_POWER_ENABLED = VTSS_PHY_POWER_ACTIPHY +  VTSS_PHY_POWER_DYNAMIC /**< ActiPHY + PerfectReach enabled */
} vtss_phy_power_mode_t;

/** \brief PHY power configuration */
typedef struct {
    vtss_phy_power_mode_t mode; /**< Power mode */
} vtss_phy_power_conf_t;

/**
 * \brief Get PHY power configuration.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param conf [OUT]    PHY power configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_power_conf_get(const vtss_inst_t      inst,
                                const vtss_port_no_t   port_no,
                                vtss_phy_power_conf_t  *const conf);

/**
 * \brief Set PHY power configuration.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param conf [IN]     PHY power configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_power_conf_set(const vtss_inst_t            inst,
                                const vtss_port_no_t         port_no,
                                const vtss_phy_power_conf_t  *const conf);

#define VTSS_PHY_ACTIPHY_PWR        100 /**< ActiPHY power status */
#define VTSS_PHY_LINK_DOWN_PWR      200 /**< Link down power status */
#define VTSS_PHY_LINK_UP_FULL_PWR   400 /**< Link up full power status */

/** \brief PHY power status */
typedef struct {
    u32 level;  /**< Usage level */
} vtss_phy_power_status_t;

/**
 * \brief Get PHY power status.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param status [OUT]  PHY power configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_power_status_get(const vtss_inst_t        inst,
                                  const vtss_port_no_t     port_no,
                                  vtss_phy_power_status_t  *const status);

/* - Clock configuration ---------- -------------------------------- */

/** \brief PHY active clock out */
#define VTSS_PHY_RECOV_CLK1     0    /**< RCVRD_CLK1 */
#define VTSS_PHY_RECOV_CLK2     1    /**< RCVRD_CLK2 */
#define VTSS_PHY_RECOV_CLK_NUM  2    /**< Number of recovered clocks */
typedef u16 vtss_phy_recov_clk_t;    /**< Container of recovered clock out identifier */

/** \brief PHY clock sources */
typedef enum {
    VTSS_PHY_CLK_DISABLED, /**< Recovered Clock Disable */
    VTSS_PHY_SERDES_MEDIA, /**< SerDes PHY */
    VTSS_PHY_COPPER_MEDIA, /**< Copper PHY */
    VTSS_PHY_TCLK_OUT,     /**< Transmitter TCLK */
    VTSS_PHY_LOCAL_XTAL    /**< Local XTAL */
} vtss_phy_clk_source_t;

/** \brief PHY clock frequencies */
typedef enum {
    VTSS_PHY_FREQ_25M,  /**< 25 MHz */
    VTSS_PHY_FREQ_125M, /**< 125 MHz */
    VTSS_PHY_FREQ_3125M /**< 31.25 MHz This is only valid on ATOM family - NOT Enzo*/
} vtss_phy_freq_t;

/** \brief PHY clock squelch levels */
typedef enum {
    VTSS_PHY_CLK_SQUELCH_MAX,
    VTSS_PHY_CLK_SQUELCH_MED,
    VTSS_PHY_CLK_SQUELCH_MIN,
    VTSS_PHY_CLK_SQUELCH_NONE
} vtss_phy_clk_squelch;

/** \brief PHY clock configuration */
typedef struct {
    vtss_phy_clk_source_t src;     /**< Clock source */
    vtss_phy_freq_t       freq;    /**< Clock requency */
    vtss_phy_clk_squelch  squelch; /**< Clock squelsh level */
} vtss_phy_clock_conf_t;

/**
 * \brief Set PHY clock configuration.
 *
 * \param inst [IN]        Target instance reference.
 * \param port_no [IN]     Port number to become clock source.
 * \param clock_port [IN]  Set configuration for this clock port.
 * \param conf [IN]        PHY clock configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_clock_conf_set(const vtss_inst_t            inst,
                                const vtss_port_no_t         port_no,
                                const vtss_phy_recov_clk_t   clock_port,
                                const vtss_phy_clock_conf_t  *const conf);


/**
 * \brief Get PHY clock configuration.
 *
 * \param inst [IN]            Target instance reference.
 * \param port_no [IN]         Port number of the first port at this PHY instance.
 * \param clock_port [IN]      Get configuration for this clock port.
 * \param conf [OUT]           PHY clock configuration.
 * \param clock_source [OUT]   Port number that is clock source for this clock_port.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_clock_conf_get(const vtss_inst_t            inst,
                                const vtss_port_no_t         port_no,
                                const vtss_phy_recov_clk_t   clock_port,
                                vtss_phy_clock_conf_t        *const conf,
                                vtss_port_no_t               *const clock_source);


/* - I2C ---------------------------------------------------- */
/**
 * \brief I2C read
 *
 * \param inst [IN]            Target instance reference.
 * \param port_no [IN]         Port number.
 * \param i2c_mux [IN]         The i2c clock mux
 * \param i2c_reg_addr [IN]    The i2c register address to access.
 * \param i2c_device_addr [IN] The i2c address of the device to access.
 * \param value [OUT]          Pointer to where array which in going to contain the values read.
 * \param cnt [IN]             The number of registers to read
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_i2c_read(const vtss_inst_t    inst,
                          const vtss_port_no_t port_no,
                          const u8             i2c_mux,
                          const u8             i2c_reg_addr,
                          const u8             i2c_device_addr,
                          u8                   *const value,
                          u8                   cnt);


/**
 *
 * \brief I2C writes
 * \param inst [IN]            Target instance reference.
 * \param port_no [IN]         Port number.
 * \param i2c_mux [IN]         The i2c clock mux
 * \param i2c_reg_addr [IN]    The i2c register address to access.
 * \param i2c_device_addr [IN] The i2c address of the device to access.
 * \param value [IN]           Pointer to where array containing the values to write.
 * \param cnt [IN]             The number of registers to write.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_i2c_write(const vtss_inst_t    inst,
                           const vtss_port_no_t port_no,
                           const u8             i2c_mux,
                           const u8             i2c_reg_addr,
                           const u8             i2c_device_addr,
                           u8                   *value,
                           u8                   cnt);


/* - Read/write ---------------------------------------------------- */

/* PHY register pages */
#define VTSS_PHY_PAGE_STANDARD   0x0000 /**< Standard registers */
#define VTSS_PHY_PAGE_EXTENDED   0x0001 /**< Extended registers */
#define VTSS_PHY_PAGE_EXTENDED_2 0x0002 /**< Extended registers - page 2 */
#define VTSS_PHY_PAGE_EXTENDED_3 0x0003 /**< Extended registers - page 3 */
#define VTSS_PHY_PAGE_GPIO       0x0010 /**< GPIO registers */
#define VTSS_PHY_PAGE_TEST       0x2A30 /**< Test registers */
#define VTSS_PHY_PAGE_TR         0x52B5 /**< Token ring registers */

/* PHY register page access for a single register can be done
   using an OR operation of the register address and the page below */
#define VTSS_PHY_REG_STANDARD (VTSS_PHY_PAGE_STANDARD<<5) /**< Standard registers */
#define VTSS_PHY_REG_EXTENDED (VTSS_PHY_PAGE_EXTENDED<<5) /**< Extended registers */
#define VTSS_PHY_REG_GPIO     (VTSS_PHY_PAGE_GPIO<<5)     /**< GPIO registers */
#define VTSS_PHY_REG_TEST     (VTSS_PHY_PAGE_TEST<<5)     /**< Test registers */
#define VTSS_PHY_REG_TR       (VTSS_PHY_PAGE_TR<<5)       /**< Token ring registers */

/**
 * \brief Read value from PHY register.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param addr [IN]     Register address. The page number is encoded in the 16 MSB.
 * \param value [OUT]   Register value.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_read(const vtss_inst_t    inst,
                      const vtss_port_no_t port_no,
                      const u32            addr,
                      u16                  *const value);


/**
 * \brief Read value from PHY register at a specific page. Page register is set to standard page when read is done.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param page [IN]     Page - Page do to the read at.
 * \param addr [IN]     Register address. The page number is encoded in the 16 MSB.
 * \param value [OUT]   Register value.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_read_page(const vtss_inst_t    inst,
                           const vtss_port_no_t port_no,
                           const u32            page,
                           const u32            addr,
                           u16                  *const value);



/**
 * \brief Read value from PHY mmd register.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param devad [IN]    Devad register address. 
 * \param addr [IN]     Register address. 
 * \param value [OUT]   Register value.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_mmd_read(const vtss_inst_t    inst,
                          const vtss_port_no_t port_no,
                          const u16            devad,
                          const u32            addr,
                          u16                  *const value);

/**
 * \brief Write value to PHY mmd register.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param devad [IN]    Devad register address. 
 * \param addr [IN]     Register address. 
 * \param value [OUT]   Register value.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_mmd_write(const vtss_inst_t    inst,
                           const vtss_port_no_t port_no,
                           const u16            devad,
                           const u32            addr,
                           u16                  value);

/**
 * \brief Write value to PHY register.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param addr [IN]     Register address. The page number is encoded in the 16 MSB.
 * \param value [IN]    Register value.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_write(const vtss_inst_t    inst,
                       const vtss_port_no_t port_no,
                       const u32            addr,
                       const u16            value);

/**
 * \brief Write masked value to PHY register.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param addr [IN]     Register address. The page number is encoded in the 16 MSB.
 * \param value [IN]    Register value.
 * \param mask [IN]     Register mask.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_write_masked(const vtss_inst_t    inst,
                              const vtss_port_no_t port_no,
                              const u32            addr,
                              const u16            value,
                              const u16            mask);


/**
 * \brief Write masked value to PHY register and setups the page register.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param page [IN]     Page number.
 * \param addr [IN]     Register address. The page number is encoded in the 16 MSB.
 * \param value [IN]    Register value.
 * \param mask [IN]     Register mask.
 *
 * \return Return code.
 **/

/* Write PHY register, masked (including page setup) */
vtss_rc vtss_phy_write_masked_page(const vtss_inst_t    inst,
                                   const vtss_port_no_t port_no,
                                   const u16            page,
                                   const u16            addr,
                                   const u16            value,
                                   const u16            mask);

/* - VeriPHY ------------------------------------------------------- */

#if VTSS_PHY_OPT_VERIPHY

/**
 * \brief Start VeriPHY.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param mode [IN]     VeriPHY mode.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_veriphy_start(const vtss_inst_t     inst,
                               const vtss_port_no_t  port_no,
                               const u8              mode);

/** \brief VeriPHY status */
typedef enum {
    VTSS_VERIPHY_STATUS_OK      = 0,  /**< Correctly terminated pair */
    VTSS_VERIPHY_STATUS_OPEN    = 1,  /**< Open pair */
    VTSS_VERIPHY_STATUS_SHORT   = 2,  /**< Short pair */
    VTSS_VERIPHY_STATUS_ABNORM  = 4,  /**< Abnormal termination */
    VTSS_VERIPHY_STATUS_SHORT_A = 8,  /**< Cross-pair short to pair A */
    VTSS_VERIPHY_STATUS_SHORT_B = 9,  /**< Cross-pair short to pair B */
    VTSS_VERIPHY_STATUS_SHORT_C = 10, /**< Cross-pair short to pair C */
    VTSS_VERIPHY_STATUS_SHORT_D = 11, /**< Cross-pair short to pair D */
    VTSS_VERIPHY_STATUS_COUPL_A = 12, /**< Abnormal cross-pair coupling, pair A */
    VTSS_VERIPHY_STATUS_COUPL_B = 13, /**< Abnormal cross-pair coupling, pair B */
    VTSS_VERIPHY_STATUS_COUPL_C = 14, /**< Abnormal cross-pair coupling, pair C */
    VTSS_VERIPHY_STATUS_COUPL_D = 15, /**< Abnormal cross-pair coupling, pair D */
    VTSS_VERIPHY_STATUS_UNKNOWN = 16  /**< Unknown */
} vtss_phy_veriphy_status_t;

/** \brief VeriPHY result */
typedef struct {
    BOOL                      link;      /**< Link status */
    vtss_phy_veriphy_status_t status[4]; /**< Status, pair A-D (0-3) */
    u8                        length[4]; /**< Length (meters), pair A-D (0-3) */
} vtss_phy_veriphy_result_t;

/**
 * \brief Get VeriPHY result.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param result [OUT   VeriPHY result.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_veriphy_get(const vtss_inst_t          inst,
                             const vtss_port_no_t       port_no,
                             vtss_phy_veriphy_result_t  *const result);

#endif /* VTSS_PHY_OPT_VERIPHY */

/** \brief EEE mode */
typedef enum {
    EEE_DISABLE,  /* Update EEE state to disabled */
    EEE_ENABLE,   /* Update EEE state to enabled */
    EEE_REG_UPDATE, /* Update EEE register with current state */
} vtss_eee_mode_t;

/** \brief EEE configuration */
typedef struct {
    vtss_eee_mode_t        eee_mode;   /**< EEE mode.  */
    BOOL                   eee_ena_phy; /**< Signaling current state in the phy api */
} vtss_phy_eee_conf_t;


/**
 * \brief Setting the LEDs blink mode
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number the port in question.
 * \param led_mode_select [IN] The LEDs mode
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_led_mode_set(const vtss_inst_t            inst,
                              const vtss_port_no_t         port_no,
                              const vtss_phy_led_mode_select_t led_mode_select);


#if defined(VTSS_FEATURE_LED_POW_REDUC)
/** \brief PHY led intensity */
typedef u8  vtss_phy_led_intensity;   /**< LED intensity from 0-200, LED intensity led_intensity * 0.5 */

/** \brief enhanced LED control */
typedef struct {
    BOOL ser_led_output_1;  /**<Set to TRUE if hardware board uses serial LEDs at SFP_SERIALCLK, SFP_SERIALDATA, SFP0_SD and SFP1_SD pins. */  
    BOOL ser_led_output_2;  /**<Set to TRUE if hardware board uses serial LEDs at PHY0, PHY1, PHY2 and PHY3 LED1 pins. */  
    u8   ser_led_frame_rate; /**<Serial LED frame rate.  0x0 = 2500Hz, 0x1 = 1000 Hz, 0x2 = 500 Hz, 0x3 = 250 Hz, 0x4 = 200 Hz, 0x5 = 125 Hz, 0x6 = 40 Hz  */  
    u8   ser_led_select;     /**<The number of LEDs the hardware board supports for each PHY,  0x00 = 4 LEDs, 0x01 = 3 LEDs, 0x2 = 2 LEDs, 0x3 = 1 LED*/  
} vtss_phy_enhanced_led_control_t;


/**
 * \brief Setting the LEDs  intensity
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number - Don't care for time being (Just set to a valid port), since all LEDs intensities are set to the same.
 * \param intensity [IN] The LEDs intensities in % (0-100)
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_led_intensity_set(const vtss_inst_t            inst,
                                   const vtss_port_no_t         port_no,
                                   const vtss_phy_led_intensity intensity);




/**
 * \brief Getting the LEDs intensity
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number - Don't care for time being (Just set to a valid port), since all LEDs intensities are set to the same.
 * \param intensity [IN] The LEDs intensities in % (0-100)
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_led_intensity_get(const vtss_inst_t            inst,
                                   const vtss_port_no_t         port_no,
                                   vtss_phy_led_intensity       *intensity);




/**
 * \brief Setting the enhanced LED control initial state (Should only be set once at startup)..
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param conf [IN]     Enhanced LED control configuration 
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_enhanced_led_control_init(const vtss_inst_t            inst,
                                           const vtss_port_no_t         port_no,
                                           const vtss_phy_enhanced_led_control_t conf);



/**
 * \brief Getting the enhanced LED control initial state (Should only be set once at startup)..
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param conf [IN]     Enhanced LED control configuration 
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_enhanced_led_control_init_get(const vtss_inst_t            inst,
                                               const vtss_port_no_t         port_no,
                                               vtss_phy_enhanced_led_control_t *conf);



 #endif


/**
 * \brief Pulling the coma mode pin low 
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number (Any port number for the PHY which shall pull the coma mode pin low).
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_coma_mode_disable(const vtss_inst_t            inst,
                                   const vtss_port_no_t         port_no);



/** \brief debug function for Atom family Rev. A. chips */
void vga_adc_debug(u8 vga_adc_pwr, u8 phy);


/**
 * \brief Get information about if a port is EEE capable
 *
 * \param inst [IN]          Target instance reference.
 * \param port_no [IN]       Port number 
 * \param eee_capable [OUT]  True if port is EEE capable else FALSE
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_port_eee_capable(const vtss_inst_t           inst,
                                  const vtss_port_no_t        port_no,
                                  BOOL                        *eee_capable);

/**
 * \brief Enabling / Disabling EEE (Energy Efficient Ethernet)
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number 
 * \param enable [IN]   Enable EEE
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_eee_ena(const vtss_inst_t           inst,
                         const vtss_port_no_t        port_no,
                         const BOOL                  enable);


/**
 * \brief Getting the current EEE (Energy Efficient Ethernet) configuration
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number. 
 * \param conf [OUT]     EEE configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_eee_conf_get(const vtss_inst_t           inst,
                              const vtss_port_no_t        port_no,
                              vtss_phy_eee_conf_t         *conf);


/**
 * \brief Setting the EEE (Energy Efficient Ethernet) configuration
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number.
 * \param conf [OUT]    EEE configuration.
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_eee_conf_set(const vtss_inst_t           inst,
                              const vtss_port_no_t        port_no,
                              const vtss_phy_eee_conf_t   conf);




/**
 * \brief Getting the if phy is currently powered save mode due to EEE
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number 
 * \param rx_in_power_save_state [OUT]  TRUE is phy rx part is in power save mode
 * \param tx_in_power_save_state [OUT]  TRUE is phy tx part is in power save mode
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_eee_power_save_state_get(const vtss_inst_t           inst,
                                          const vtss_port_no_t        port_no,
                                          BOOL  *rx_in_power_save_state,
                                          BOOL  *tx_in_power_save_state);

/**
 * \brief Getting the EEE advertisement 
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number 
 * \param advertisement [OUT]  Advertisement bit mask. 
 *                             Bit 0 = Link partner advertises 100BASE-T capability.  
 *                             Bit 1 = Link partner advertises 1000BASE-T capability.  
 *
 * \return Return code.
 **/

vtss_rc vtss_phy_eee_link_partner_advertisements_get(const vtss_inst_t      inst,
                                                const vtss_port_no_t        port_no,
                                                u8                          *advertisement);




/* - Events ------------------------------------------------------- */
/*  PHY interrupt events */
#define VTSS_PHY_LINK_LOS_EV                    (1 << 0) /**< PHY link interrupt */
#define VTSS_PHY_LINK_FFAIL_EV                  (1 << 1) /**< PHY fast failure interrupt */
#define VTSS_PHY_LINK_AMS_EV                    (1 << 2) /**< PHY Automatic Media Sense */
#define VTSS_PHY_LINK_SPEED_STATE_CHANGE_EV     (1 << 3) /**< PHY link state change event*/
#define VTSS_PHY_LINK_FDX_STATE_CHANGE_EV       (1 << 4) /**< PHY FDX state change event*/
#define VTSS_PHY_LINK_AUTO_NEG_ERROR_EV         (1 << 5) /**< PHY Autonegotiation error event*/
#define VTSS_PHY_LINK_AUTO_NEG_COMPLETE_EV      (1 << 6) /**< PHY Autonegotiation complete event*/
#define VTSS_PHY_LINK_INLINE_POW_DEV_DETECT_EV  (1 << 7) /**< PHY Inline powered device detect event */
#define VTSS_PHY_LINK_SYMBOL_ERR_INT_EV         (1 << 8) /**< PHY Symbol error event */
#define VTSS_PHY_LINK_TX_FIFO_OVERFLOW_INT_EV   (1 << 9) /**< PHY TX fifo over/underflow detect event*/
#define VTSS_PHY_LINK_RX_FIFO_OVERFLOW_INT_EV   (1 << 10) /**< PHY RX fifo over/underflow detect event*/
#define VTSS_PHY_LINK_FALSE_CARRIER_INT_EV      (1 << 11) /**< PHY false-carrier interrupt event*/
#define VTSS_PHY_LINK_LINK_SPEED_DS_DETECT_EV   (1 << 12) /**< PHY Link speed downshift detect event*/
#define VTSS_PHY_LINK_MASTER_SLAVE_RES_ERR_EV   (1 << 13) /**< PHY master/salve resolution error event*/
#define VTSS_PHY_LINK_RX_ER_INT_EV              (1 << 14) /**< PHY RX_ER interrupt event*/

/** \brief PHY interrupt event type */
typedef  u16 vtss_phy_event_t;

/**
 * \brief Enabling / Disabling of events
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number 
 * \param ev_mask [IN]  Mask containing events that are enabled/disabled 
 * \param enable [IN]   Enable/disable of event
 *
 * \return Return code.
 **/

vtss_rc vtss_phy_event_enable_set(const vtss_inst_t         inst,
                                  const vtss_port_no_t      port_no,
                                  const vtss_phy_event_t    ev_mask,
                                  const BOOL                enable);



/**
 * \brief Getting current interrupt event state 
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number 
 * \param ev_mask [IN]  Mask containing events that are enabled/disabled 
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_event_enable_get(const vtss_inst_t         inst,
                                  const vtss_port_no_t      port_no,
                                  vtss_phy_event_t          *ev_mask);



/**
 * \brief Polling for active events
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Port number 
 * \param ev_mask [OUT] Mask containing events that are active
 *
 * \return Return code.
 **/
vtss_rc vtss_phy_event_poll(const vtss_inst_t     inst,
                            const vtss_port_no_t  port_no,
                            vtss_phy_event_t      *const ev_mask);



/* - Misc--- */

/**
 * \brief Function for enabling/disabling squelch work around.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Any phy port with the chip
 * \param enable  [IN]  TRUE = enable squelch workaround, FALSE = Disable squelch workaround
 *
 * \return VTSS_RC_OK - Workaround was enabled/disable. VTSS_RC_ERROR - Squelch workaround patch not loaded
 **/
vtss_rc vtss_squelch_workaround(const vtss_inst_t         inst,
                                const vtss_port_no_t      port_no,
                                const BOOL enable);



/* - Debug--- */
/** \brief Phy statistic information */
typedef struct
{
    u8             cu_good;    /**< Cu media CRC good packet received since last time read */
    u8             cu_bad;    /**< RC error counter for packets received on the Cu media interface. The value saturates at 0xFF and subsequently clears when read and restarts count.*/
    u16            serdes_tx_good; /**< SerDes Transmit good packet count modulo 10000*/
    u8             serdes_tx_bad;  /**< SerDes Transmit CRC packet count (saturates at 255)*/
    u8             rx_err_cnt_base_tx; /**< 100/1000BASE-TX receive error counter. 8-bit counter that saturates when it reaches
                                          255. These bits are self-clearing when read. */
} vtss_phy_statistic_t;

/**
 * \brief debug function for getting phy statistics.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Any phy port with the chip
 * \param statistics  [OUT]  Pointer to where to put the statistics.
 *
 * \return VTSS_RC_OK - Statistics is valid else statistics is invalid
 **/

vtss_rc vtss_phy_statistic_get(const vtss_inst_t    inst,
                               const vtss_port_no_t port_no,
                               vtss_phy_statistic_t *statistics);



/** \brief Internal loop-back type */
typedef enum {
    VTSS_LB_1G_NONE, 	             /**< No looback   */
    VTSS_LB_FAR_END,             /**< Loopback at far end (Loopback at cu side)  - Only valid when Enable = TRUE */
    VTSS_LB_NEAR_END,            /**< Loopback at near end (Loopback at MAC side) - Only valid when Enable = TRUE  */
} lb_type;

/** \brief Phy loopbacks */
typedef struct {
    BOOL far_end_enable;                     /**< Enable/Disable loopback far end loopback  */
    BOOL near_end_enable;                     /**< Enable/Disable loopback near end loopback  */
} vtss_phy_loopback_t; 


/**
 * \brief Debug function for enabling check of page register for all phy register accesses
 *
 * \param inst [IN]     Target instance reference.
 * \param enable [IN]   TRUE to enable phy page register check. FALSE to disable 
 *
 * \return Return code. VTSS_RC_OK if phy page check were set.
 **/
vtss_rc vtss_phy_do_page_chk_set(const vtss_inst_t    inst,
                                 const BOOL enable);


/**
 * \brief Debug function for getting if check of page register is enabled
 *
 * \param inst [IN]     Target instance reference.
 * \param enable [OUT]   TRUE if phy page register check is enabled else FALSE
 *
 * \return Return code. VTSS_RC_OK when enable is valid.
 **/
vtss_rc vtss_phy_do_page_chk_get(const vtss_inst_t    inst,
                                 BOOL *enable);


/**
 * \brief Debug function for setting phy internal loopback
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Phy port that should have the internal loopback
 * \param loopback [IN] Loopback type
 *
 * \return Return code. VTSS_RC_OK if firmware is loaded correctly else VTSS_RC_ERROR
 **/
vtss_rc vtss_phy_loopback_set(const vtss_inst_t    inst,
                              const vtss_port_no_t port_no,
                              vtss_phy_loopback_t  loopback);


/**
 * \brief Debug function for getting the current phy internal loopback
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Phy port that with the internal loopback
 * \param loopback [IN] Current loopback type
 *
 * \return Return code. VTSS_RC_OK if firmware is loaded correctly else VTSS_RC_ERROR
 **/
vtss_rc vtss_phy_loopback_get(const vtss_inst_t       	inst,
                              const vtss_port_no_t   	port_no,
                              vtss_phy_loopback_t	*loopback);


/**
 * \brief Debug function for checking if the phy firmware is loaded correctly
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  Must the first PHY port within the chip.
 * \param code_length [IN]   The length of the microcode patch 
 * \param expected_crc [IN]  The expected CRC.
 *
 * \return Return code. VTSS_RC_OK if firmware is loaded correctly else VTSS_RC_ERROR
 **/
vtss_rc vtss_phy_is_8051_crc_ok(const vtss_inst_t       inst,
                                const vtss_port_no_t   	port_no,
                                u16                     code_length,
                                u16                     expected_crc);

/**
 * \brief Debug function for setting the ob post0 patch.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  PHY port within the chip.
 * \param value [IN]    The value to call the ob post0 patch with.
 *
 * \return Return code. VTSS_RC_OK if patch were updated correct else VTSS_RC_ERROR
 **/
   
vtss_rc vtss_phy_cfg_ob_post0(const vtss_inst_t       inst,
                              const vtss_port_no_t    port_no,
                              const u16               value);

/**
 * \brief Debug function for setting the ib cterm patch.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  PHY port within the chip.
 * \param ib_cterm_ena [IN]    The value of ib_cterm_ena to call the ib cterm patch with.
 * \param ib_eq_mode [IN]    The value of ib_eq_mode to call the ib cterm patch with.
 *
 * \return Return code. VTSS_RC_OK if patch were updated correct else VTSS_RC_ERROR
 **/
vtss_rc vtss_phy_cfg_ib_cterm(const vtss_inst_t       inst,
                              const vtss_port_no_t    port_no,
                              const u8                ib_cterm_ena, 
                              const                   u8 ib_eq_mode);


/**
 * \brief Debug function for getting PHY setting set by the micro patches.
 *
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]  PHY port within the chip.
 * \param mcb_bus [INOUT]  If set to 2 the returned data is for LCPLL/RComp else the mcb_bus is returning 0 if the data is for 1G, and returning 1 if the data is for 6G .
 * \param cfg_buf [IN]    Pointer to array where to put the current settings.
 * \param stat_buf [IN]   Pointer to array where to put the current status.
 *
 * \return Return code. VTSS_RC_OK if patch were updated correct else VTSS_RC_ERROR
 **/
vtss_rc vtss_phy_atom12_patch_setttings_get(const vtss_inst_t       inst,
                                            const vtss_port_no_t    port_no,
                                            u8                      *mcb_bus,
                                            u8                      *cfg_buf,
                                            u8                      *stat_buf);
    


/**
 * \brief Function for updating the status via the result from PHY registers
 * \param port_no [IN]    The port in question.
 * \param lp_auto_neg_advertisment_reg [IN] The value from the register containing the Link partners auto negotiation advertisement (Standard page 5)
 * \param lp_1000base_t_status_reg [IN] The value from the register containing the Link partners 1000BASE-T Status (Standard page 10)
 * \param mii_status_reg [IN] The value from the register containing mii status (Standard page 1)
 * \param phy_setup      [IN] The phy configuration setup
 * \param status [INOUT]  Pointer to where to put the result */

void vtss_phy_reg_decode_status(vtss_port_no_t port_no, 
                                u16 lp_auto_neg_advertisment_reg, 
                                u16 lp_1000base_t_status_reg, u16 mii_status_reg, 
                                const vtss_phy_conf_t phy_setup, 
                                vtss_port_status_t *const status);



/**
 * \brief Function for finding flow control status based upon configuration and PHY registers.
 * \param inst [IN]     Target instance reference.
 * \param port_no [IN]    The port in question.
 * \param lp_auto_neg_advertisment_reg [IN] The value from the register containing the Link partners auto negotiation advertisement (Standard page 5)
 * \param phy_setup      [IN] The phy configuration setup
 * \param status [INOUT]  Pointer to where to put the result */
vtss_rc vtss_phy_flowcontrol_decode_status(const vtss_inst_t       inst,
                                           const vtss_port_no_t port_no, 
                                           u16 lp_auto_neg_advertisment_reg, 
                                           const vtss_phy_conf_t phy_setup, 
                                           vtss_port_status_t *const status);

#endif // VTSS_CHIP_CU_PHY
#endif /* _VTSS_PHY_API_H_ */


